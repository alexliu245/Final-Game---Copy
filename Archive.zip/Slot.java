/**
 * @(#)Slot.java
 *
 *
 * @author 
 * @version 1.00 2014/5/20
 */

import java.awt.event.*;
import javax.swing.*;
import java.awt.*;
import java.awt.geom.*;
import java.util.*;
import java.io.*;

public class Slot{
	int x,y,height,width;
    public Slot(int x, int y, int h, int w){
   		this.x = x;
   		this.y = y;
   		height = h;
   		width = w;
    }
    
    
}